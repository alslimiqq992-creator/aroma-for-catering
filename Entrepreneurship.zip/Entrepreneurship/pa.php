<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<link href="https://fonts.googleapis.com/css2?family=Caveat&display=swap" rel="stylesheet">
<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
<title>Packages |AROMA </title>
<style>
body {
    margin: 0;
    padding: 0;
    font-family: 'Dessert Script', cursive;
    background-color: #C2B7A2;
    display: flex;
    flex-direction: column;
}

header {
    width: 100%;
    background-color: #E3DFCE;
    padding: 20px 50px;
    display: flex;
    justify-content: space-between;
    align-items: center;
    box-shadow: 0 2px 5px rgba(0,0,0,0.1);
    color: black;
}

nav a {
    color: black;
    text-decoration: none;
    margin-left: 30px;
    font-size:50px;
    font-style: italic;
    font-weight: bold;
    transition: color 0.3s ease;
}

nav a:hover {
    color: white;
}
footer {
    width: 100%;
    background-color:#E3DFCE;
    padding:0px 10px 10px;
    display: flex;
    flex-direction: column;
    justify-content: center;
    align-items: center;

    box-shadow: 0 2px 5px rgba(0,0,0,0.1);
    color:black;  
    font-size: 20px;
	position: fixed; 
	bottom: 0;        
    left: 0;
	line-height: 1.2;
}

footer h2 {
    margin: 0 0 10px;
    font-size: 35px;
	color:black;
	font-weight:bold;
	text-align: center; 
}

.social-links {
    display: flex;
    gap: 15px;
    margin-bottom: 10px;
	font-weight:bold;
}

.social-links a {
    color: black;
    font-size: 25px;
    text-decoration: none;
    transition: opacity 0.3s;
}

.social-links a:hover {
text-decoration: underline;
}

.social-links .whatsapp {
  color: #25D366; 
  font-size: 28px;
text-decoration: underline;  
}
.social-links .instagram {
  color: #C13584; 
  font-size: 28px;
  text-decoration: underline;
}



.email-line {
    display: flex;
    align-items: center;
    gap:10px;
    font-weight: bold;
    font-size:25px;
	justify-content: center;

}

.email-line a {
    color:black;
    text-decoration: none;
}

.email-line a:hover {
    text-decoration: underline;
}
.email-line i {
  color: #0078D4; 
  font-size: 28px;
}
<!--=============================================================-->
>
body {
    margin: 0;
    padding: 0;
    font-family: 'Dessert Script', cursive;
    background-color: #C2B7A2;
}

header {
    width: 100%;
    background-color: #E3DFCE;
    padding: 20px 50px;
    display: flex;
    justify-content: space-between;
    align-items: center;
    box-shadow: 0 2px 5px rgba(0,0,0,0.1);
}

nav a {
    color: black;
    text-decoration: none;
    margin-left: 30px;
    font-size: 40px;
    font-style: italic;
    font-weight: bold;
    transition: color 0.3s ease;
}

nav a:hover {
    color: white;
}

.packages-wrapper {
    display: flex;
    justify-content: center;
    width: 100%;
    padding: 50px 0 200px;
    background-color: #f5f1eb;
	
}
.packages {
    display: flex;
    gap: 40px;
    flex-wrap: nowrap;
    overflow-x: auto;
    scroll-behavior: smooth;
    padding: 0 20px;
	justify-content: center;
	
}

.package {
    background-color: #E3DFCE;
    padding: 20px;
    border-radius: 25px;
    box-shadow: 0 4px 10px rgba(0,0,0,0.1);
    text-align: center;
    width:800px;
    flex-shrink: 0;
    transition: transform 0.3s, box-shadow 0.3s;
}

.package:hover {
    transform: scale(0.9);
    box-shadow: 0 8px 20px rgba(0,0,0,0.2);
}

.package img {
    width: 100%;
    height:800px;
    object-fit:cover;
    border-radius: 15px;
    margin-bottom:0px;
}

.package h3 {
    font-family:cursive;
    font-size:70px;
    margin-bottom:5px;
    color: #333;
	font-weight:bold;
	color:red;
}

.package p {
    font-family: 'Dessert Script', cursive;
    font-size:35px;
    line-height: 1.6;
    margin-top:-1px;
    margin-bottom:8px;
    color: #333;
	font-weight:bold;
}

@media (max-width: 768px) {
    .packages {
        gap: 20px;
    }
    .package {
        width: 250px;
    }
}

@media (max-width: 450px) {
    .package {
        width: 200px;
        padding: 15px;
    }
    .package h3 {
        font-size: 20px;
    }
    .package p {
        font-size: 14px;
    }
}
h1{
	text-align: center;
	font-size:100px;
	font-weight:bold;
	font-family:Caveat;
}
</style>
</head>
<body>
  <header>
  <nav>
<a href="h1.php">Home</a>
  </nav>
  </header>
<h1>Packages</h1>
<section class="packages">
  <div class="package">
    <img src="img/n2.jpg" alt="Classic" >
    <h3>Classic</h3>
    <p>Designed for small to medium-sized conferences and events.Includes
	a selection of traditional dishes with a modern presentation, elegant
	table setup, and professional service staff. Ideal for clients 
	seeking quality and sophistication at a practical scale.</p>
  </div>
  
  <div class="package">
    <img src="img/n3.jpg" alt="Premium">
    <h3>Premium</h3>
    <p>Offers a full experience with premium menu options, 
	customized serving designs inspired by the theme of the event, 
	and advanced coordination services.Perfect for official events, cultural occasions, and corporate gatherings with international guests.</p>
  </div>

  <div class="package">
    <img src="img/n1.jpg" alt="VIP">
    <h3>VIP</h3>
    <p>Our highest-tier service, created for elite and high-profile 
	events.Includes a fully personalized menu, exclusive plating
	design, private on-site chefs, and luxury service details that 
	reflect the client’s identity and event concept.</p>
  </div>
</section>



<footer>
  <div class="fooS">
    <div class="footer-content">
      <h2>CONTACT :</h2>

      <div class="social-links">
        <a href="https://wa.me/968XXXXXXXX" target="_blank">
          <i class="fab fa-whatsapp whatsapp"></i> +968 9333 5120
        </a>
        <a href="https://www.instagram.com/" target="_blank">
          <i class="fab fa-instagram instagram"></i> Aroma.om
        </a>
      </div>

      <div class="email-line">
        <i class="fas fa-envelope"></i>
        <a href="mailto:folk@gmail.com">AROMA@gmail.com</a>
      </div>

    </div>
  </div>
</footer>
</body>
</html>
