<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<link href="https://fonts.googleapis.com/css2?family=Caveat&display=swap" rel="stylesheet">
  <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
<title>About Us | AROMA </title>
<style>
/* ====== Body ====== */
body {
    margin: 0;
    padding: 0;
    font-family: 'Dessert Script', cursive;
    background-color: #C2B7A2;
    display: flex;
    justify-content: center;
    align-items: center;
    flex-direction: column;
	
}
/* ====== Header ====== */
header {
    width: 100%;
    background-color: #E3DFCE;
    padding: 20px 50px;
    display: flex;
    justify-content: space-between;
    align-items: center;
    box-shadow: 0 2px 5px rgba(0,0,0,0.1);
	font-weight:bold;
	 
}

nav a {
    color: black;
    text-decoration: none;
    margin-left: 30px;
    font-size:50px;
}

nav a:hover {
    color: white;
}
footer {
    width: 100%;
    background-color:#E3DFCE;
    padding:0px 10px 10px;
    display: flex;
    flex-direction: column;
    justify-content: center;
    align-items: center;

    box-shadow: 0 2px 5px rgba(0,0,0,0.1);
    color:black;  
    font-size: 20px;
	position: fixed; 
	bottom: 0;        
    left: 0;
	line-height: 1.2;
}

footer h2 {
    margin: 0 0 10px;
    font-size: 35px;
	color:black;
	font-weight:bold;
	text-align: center; 
}

.social-links {
    display: flex;
    gap: 15px;
    margin-bottom: 10px;
	font-weight:bold;
}

.social-links a {
    color: black;
    font-size: 25px;
    text-decoration: none;
    transition: opacity 0.3s;
}

.social-links a:hover {
text-decoration: underline;
}

.social-links .whatsapp {
  color: #25D366; 
  font-size: 28px;
text-decoration: underline;  
}
.social-links .instagram {
  color: #C13584; 
  font-size: 28px;
  text-decoration: underline;
}



.email-line {
    display: flex;
    align-items: center;
    gap:10px;
    font-weight: bold;
    font-size:25px;
	justify-content: center;

}

.email-line a {
    color:black;
    text-decoration: none;
}

.email-line a:hover {
    text-decoration: underline;
}
.email-line i {
  color: #0078D4; 
  font-size: 28px;
}
<!--=========================================================-->
section {
	
    width: 100%;
    overflow: hidden;
    background-color: #f5f1eb;
    padding: 20px 0;
    text-align: center;
    position: relative;
    display: flex;
    flex-direction: column;
    justify-content: center; 
    align-items: center;  
}

section h2 {
    font-weight: bold;
    font-size:150px;
    margin-bottom:10px;
	font-family:Caveat;
	text-align: center;
}

.marquee {
    display: inline-block;
    white-space: nowrap;
    animation: slideToCenter 8s forwards;
	
	
	
}

.marquee p {
    display: inline-block;
    align-items:center;
    line-height:1;
	font-family:Caveat;
	font-size:100px;
	font-weight:bold;
	margin-bottom:20%;  

}

@keyframes slideToCenter {
    0% {
        transform: translateX(100%);
    }
    100% {
        transform: translateX(0%);
    }
}

@media (max-width: 768px) {
    section h2 {
        font-size: 40px;
    }
    .marquee p {
        font-size: 16px;
        margin: 0 30px;
    }
}

@media (max-width: 450px) {
    section h2 {
        font-size: 30px;
    }
    .marquee p {
        font-size: 14px;
        margin: 0 20px;
    }
}

</style>
</head>
<body>
  <header>
  <nav>
<a href="h1.php">Home</a>
  </nav>
  </header>
<section>

  <h2>Our Story</h2>
  <div class="marquee">
  <br>
  <p>High-end hospitality for conferences and large events, especially<br> 
  those with guests from outside the country.
  <br><br>
  Our goal is to offer traditional dishes with authentic flavors,<br> 
  presented in an elegant and modern way that reflects our country's <br>
  character and leaves guests with a positive impression of our culture<br>
  and taste. Hospitality is more than just food; it's an experience <br>
  that represents the occasion and beautifully expresses our identity.
  <br><br>
  Food isn't just about hospitality at a conference; it's an integral<br> 
  part of the experience itself.
  <br><br>
  For example, if we have a conference about oil or the environment,<br> 
  we choose colors and presentation that evoke the feeling of the <br>
  desert and nature. If it's about innovation, we use modern touches <br>
  and contemporary colors.
  <br><br>
  In other words, we transform food into a work of art that reflects <br>
  the theme of the event and expresses the country's identity while <br>
  maintaining an authentic flavor and a sophisticated touch.</p>

 <div>
</section>
<br><br><br>
<footer>
  <div class="fooS">
    <div class="footer-content">
      <h2>CONTACT :</h2>

      <div class="social-links">
        <a href="https://wa.me/968XXXXXXXX" target="_blank">
          <i class="fab fa-whatsapp whatsapp"></i> +968 9333 5120
        </a>
        <a href="https://www.instagram.com/" target="_blank">
          <i class="fab fa-instagram instagram"></i> Aroma.om
        </a>
      </div>

      <div class="email-line">
        <i class="fas fa-envelope"></i>
        <a href="mailto:folk@gmail.com">AROMA@gmail.com</a>
      </div>

    </div>
  </div>
</footer>
</body>
</html>
