<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8">
	<meta name="viewport" content="width=device-width, initial-scale=1.0">
  <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
<title>Booking Page</title>
<style>
/* ====== Header ====== */
header {
    width: 100%;
    background-color: #E3DFCE;
    padding: 20px 50px;
    display: flex;
    justify-content: space-between;
    align-items: center;
    box-shadow: 0 2px 5px rgba(0,0,0,0.1);
	font-weight:bold;
	font-size:50px;
}

nav a {
    color: black;
    text-decoration: none;
    margin-left: 30px;
    
}

nav a:hover {
    color: white;
}
/* Confirmation message styling */
#confirmationMessage {
    width:10%;
    border: 8px dotted #828282;
    background-color:#E2E2E2;
    display: none;
    opacity: 0;
    transition: opacity 0.8s ease-in-out;
    text-align: center;
	border-radius:35%; 
    width:500px;               
    height:150px;	
}

#confirmationMessage.show {
    display: block;
    opacity: 1;
	
}

/* ====== Body ====== */
body {
    margin: 0;
    padding: 0;
    font-family: 'Dessert Script', cursive;
    background-color: #C2B7A2;
    display: flex;
    justify-content: center;
    align-items: center;
    flex-direction: column;
}

.form-box {
    display: flex;
    flex-direction: column;
    width: 400px;
    padding: 30px;
    border-radius: 15px;
    background-color: white;
    box-shadow: 0 0 15px rgba(0,0,0,0.1);
}

.form-box form {
    display: flex;
    flex-direction: column;
    gap: 15px;
}

.form-row {
    display: flex;
    align-items: center;
    gap: 10px;
}

.form-row label {
    width: 150px;
    font-weight: bold;
    text-align:left;
	font-size:20px;
}

.form-row input,
.form-row select {
    flex: 1;
    padding: 10px;
    border: 1px solid #aaa;
    border-radius: 8px;
	font-size:20px;
	font-weight:bold;
	width:200px;
}

.form-box input[type="submit"] {
    width: 150px;
    padding: 12px;
    border: none;
    border-radius: 5px;
    font-weight: bold;
    color: black;
    cursor: pointer;
    font-size: 20px;
    align-self: center;
    margin-top: 10px;
    background-color:#E3DFCE;
}

.form-box input[type="submit"]:hover {
    background-color: #C2B7A2;
}
footer {
    width: 100%;
    background-color:#E3DFCE;
    padding:0px 10px 10px;
    display: flex;
    flex-direction: column;
    justify-content: center;
    align-items: center;

    box-shadow: 0 2px 5px rgba(0,0,0,0.1);
    color:black;  
    font-size: 20px;
	position: fixed; 
	bottom: 0;        
    left: 0;
	line-height: 1.2;
}

footer h2 {
    margin: 0 0 10px;
    font-size: 35px;
	color:black;
	font-weight:bold;
	text-align: center; 
}

.social-links {
    display: flex;
    gap: 15px;
    margin-bottom: 10px;
	font-weight:bold;
}

.social-links a {
    color: black;
    font-size: 25px;
    text-decoration: none;
    transition: opacity 0.3s;
}

.social-links a:hover {
text-decoration: underline;
}

.social-links .whatsapp {
  color: #25D366; 
  font-size: 28px;
text-decoration: underline;  
}
.social-links .instagram {
  color: #C13584; 
  font-size: 28px;
  text-decoration: underline;
}



.email-line {
    display: flex;
    align-items: center;
    gap:10px;
    font-weight: bold;
    font-size:25px;
	justify-content: center;

}

.email-line a {
    color:black;
    text-decoration: none;
}

.email-line a:hover {
    text-decoration: underline;
}
.email-line i {
  color: #0078D4; 
  font-size: 28px;
}
@media (max-width: 450px) {
    .register-container {
        width: 90%;
        padding: 20px;
    }

</style>
</head>
<body>
 <header>
    <nav>
      <a href="h1.php">Home</a>
    </nav>
  </header>
<h1>Booking Page</h1>

<div class="form-box">
  <form id="bookingForm">
    <div class="form-row">
      <label for="ev">Event:</label>
      <input type="text" id="ev" required>
    </div>
    <div class="form-row">
      <label for="gn">Guests No:</label>
      <input type="number" id="gn" min="10" step="1" required>
    </div>
    <div class="form-row">
      <label for="dt">Date:</label>
      <input type="date" id="dt" required>
    </div>
    <div class="form-row">
      <label for="pg">Packaging:</label>
      <select id="pg">
        <option value="Classic">Classic</option>
        <option value="Premium">Premium</option>
        <option value="VIP">VIP</option>
      </select>
    </div>
    <div class="form-row">
      <label for="lo">Location:</label>
      <input type="text" id="lo" required>
    </div>
    <input type="submit" value="BOOK NOW">
  </form>
</div>
<br>
<!-- Confirmation message -->
<div id="confirmationMessage">
  <h2>Booking Confirmed!</h2>
  <p>Thank you for choosing us. Our team will contact you shortly.</p>
</div>

<script>
const form = document.getElementById('bookingForm');
const confirmation = document.getElementById('confirmationMessage');

form.addEventListener('submit', function(e) {
  e.preventDefault(); // prevent page reload

  // Show the confirmation message immediately
  confirmation.classList.add('show');

  // Hide the message after 10 seconds
  setTimeout(() => {
    confirmation.classList.remove('show');
  }, 10000); // 10000 ms = 10 seconds

  form.reset(); // optional: reset form fields
});
</script>
<footer>
  <div class="fooS">
    <div class="footer-content">
      <h2>CONTACT :</h2>

      <div class="social-links">
        <a href="https://wa.me/968XXXXXXXX" target="_blank">
          <i class="fab fa-whatsapp whatsapp"></i> +968 9333 5120
        </a>
        <a href="https://www.instagram.com/" target="_blank">
          <i class="fab fa-instagram instagram"></i> Aroma.om
        </a>
      </div>

      <div class="email-line">
        <i class="fas fa-envelope"></i>
        <a href="mailto:folk@gmail.com">AROMA@gmail.com</a>
      </div>

    </div>
  </div>
</footer>
</body>
</html>
