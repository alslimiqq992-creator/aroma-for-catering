<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Register Page</title>
	<meta name="viewport" content="width=device-width, initial-scale=1.0">
  <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
</head>
  <style>
body {
    margin: 0;
    padding: 0;
    font-family: 'Dessert Script', cursive;
    background-color: #C2B7A2;
    display: flex;
    flex-direction: column;
    min-height:70vh;
}

header {
    width: 100%;
    background-color: #E3DFCE;
    padding: 20px 50px;
    display: flex;
    justify-content: space-between;
    align-items: center;
    box-shadow: 0 2px 5px rgba(0,0,0,0.1);
    color: black;
}

nav a {
    color: black;
    text-decoration: none;
    margin-left: 30px;
    font-size: 40px;
    font-style: italic;
    font-weight: bold;
    transition: color 0.3s ease;
}

nav a:hover {
    color: white;
}

main {
    flex: 1;
    display: flex;
    flex-direction: column;
    justify-content: center;
    align-items: center;
    gap: 20px;
    padding: 0;
    margin: 0;
}

main h2 {
    margin: 0;
    color:black;
    text-align: center;
    font-size: 30px;
    font-weight: bold;
}

.register-container {
    background-color: #ffffff;
    padding: 30px 40px;
    border-radius: 12px;
    box-shadow: 0 5px 15px rgba(0,0,0,0.2);
    width: 400px;
    display: flex;
    flex-direction: column;
    align-items: center;
    justify-content: center;
}

.register-container h2 {
    margin-bottom: 20px;
    color: #6a506b;
    text-align: center;
}

.register-form {
    display: flex;
    flex-direction: column;
    width: 100%;
    align-items: center;
    justify-content: center;
}

.form-row {
    display: flex;
    align-items: center;
    justify-content: space-between;
    width: 100%;
    margin-bottom: 15px;
}

.form-row label {
    width: 30%;
    font-weight: bold;
    color: #333;
}

.form-row input {
    width: 65%;
    padding: 8px;
    border: 1px solid #ccc;
    border-radius: 5px;
    font-size: 16px;
}

.form-row input:focus {
    border-color: #d7a8c4;
    outline: none;
    box-shadow: 0 0 5px rgba(215, 168, 196, 0.5);
}

.register-form button {
    margin-top: 20px;
    padding: 12px;
    background-color: #E3DFCE;
    border: none;
    border-radius: 5px;
    font-weight: bold;
    color: black;
    font-size: 16px;
    cursor: pointer;
    transition: background-color 0.3s;
}

.register-form button:hover {
    background-color: #c694b3;
}

footer {
    width: 100%;
    background-color:#E3DFCE;
    padding:0px 10px 10px;
    display: flex;
    flex-direction: column;
    justify-content: center;
    align-items: center;

    box-shadow: 0 2px 5px rgba(0,0,0,0.1);
    color:black;  
    font-size: 20px;
	position: fixed; 
	bottom: 0;        
    left: 0;
	line-height: 1.2;
}

footer h2 {
    margin: 0 0 10px;
    font-size: 35px;
	color:black;
	font-weight:bold;
	text-align: center; 
}

.social-links {
    display: flex;
    gap: 15px;
    margin-bottom: 10px;
	font-weight:bold;
}

.social-links a {
    color: black;
    font-size: 25px;
    text-decoration: none;
    transition: opacity 0.3s;
}

.social-links a:hover {
text-decoration: underline;
}

.social-links .whatsapp {
  color: #25D366; 
  font-size: 28px;
text-decoration: underline;  
}
.social-links .instagram {
  color: #C13584; 
  font-size: 28px;
  text-decoration: underline;
}



.email-line {
    display: flex;
    align-items: center;
    gap:10px;
    font-weight: bold;
    font-size:25px;
	justify-content: center;

}

.email-line a {
    color:black;
    text-decoration: none;
}

.email-line a:hover {
    text-decoration: underline;
}
.email-line i {
  color: #0078D4; 
  font-size: 28px;
}
@media (max-width: 450px) {
    .register-container {
        width: 90%;
        padding: 20px;
    }

    .form-row {
        flex-direction: column;
        align-items: flex-start;
    }

    .form-row label,
    .form-row input {
        width: 100%;
    }

    .form-row input {
        margin-top: 5px;
    }

    nav a {
        font-size: 30px;
        margin-left: 15px;
    }
}
.fooS {
    width: 100%;
    display: flex;
    justify-content: center;
}
.footer-content {
    display: flex;
    flex-direction: column;
    align-items: center;
    gap: 15px;
}

.footer-contact h2 {
    text-align: center;
    font-weight: bold;
    font-size: 28px;
    margin: 0; 
    color: black;
}
  </style>
<body>
  <header>
    <nav>
      <a href="h1.php">Home</a>
    </nav>
  </header>
<main>
  <h2>Register Page</h2>
  <div class="register-container">
    <form action="b2.php" method="POST" class="register-form">
      <div class="form-row">
        <label>First Name:</label>
        <input type="text" name="firstname" required>
      </div>
      <div class="form-row">
        <label>Last Name:</label>
        <input type="text" name="lastname" required>
      </div>
      <div class="form-row">
        <label>Phone Number:</label>
        <input type="tel" name="phone" required>
      </div>
      <div class="form-row">
        <label>Address:</label>
        <input type="text" name="address" required>
      </div>
      <button type="submit">Next</button>
    </form>
  </div>
</main>
<footer>
  <div class="fooS">
    <div class="footer-content">
      <h2>CONTACT :</h2>

      <div class="social-links">
        <a href="https://wa.me/968XXXXXXXX" target="_blank">
          <i class="fab fa-whatsapp whatsapp"></i> +968 9333 5120
        </a>
        <a href="https://www.instagram.com/" target="_blank">
          <i class="fab fa-instagram instagram"></i> Aroma.om
        </a>
      </div>

      <div class="email-line">
        <i class="fas fa-envelope"></i>
        <a href="mailto:folk@gmail.com">AROMA@gmail.com</a>
      </div>

    </div>
  </div>
</footer>
</body>
</html>
