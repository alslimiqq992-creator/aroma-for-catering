/* ====== General Page Style ====== */
body {
    margin: 0;
    font-family: 'Dessert Script', cursive;
    scroll-behavior: smooth;
    display: flex;
    flex-direction: column;
    min-height: 100vh;
	background-color: #f3e5ab;
}

/* ====== Header ====== */
header {
    width: 100%;
    background-color: #8b5a2b;
    padding: 20px 50px;
    display: flex;
    justify-content: space-between;
    align-items: center;
    box-shadow: 0 2px 5px rgba(0,0,0,0.1);
    color: white;
}

.logo {
    font-size: 35px;
    font-weight: normal;
}

/* ====== Navigation Links ====== */
nav a {
    color: white;
    text-decoration: none;
    margin-left: 30px;
    font-size: 20px;
    font-style: italic;
    font-weight: bold;
    transition: color 0.3s ease;
}

nav a:hover {
    color: #D2B48C;
}

/* ====== Main Content ====== */
main {
    flex: 1;
    display: flex;
    flex-direction: column;
    align-items: center;
    padding: 20px;
}

h1 {
    color: #654321;
    font-size: 36px;
    text-align: center;
    margin-bottom: 20px;
}

h2 {
    color: #654321;
    font-size: 20px;
    text-align: center;
    
}

/* ====== Horizontal Images ====== */
.image-row {
    display: flex;
    justify-content: center;
    gap: 20px;
    flex-wrap: wrap;
    margin-bottom: 30px;
}

.image-row img,
.section-image {
    width: 400px;
    max-width: 100%;
    height: auto;
    border-radius: 10px;
    box-shadow: 0 4px 10px rgba(0,0,0,0.2);
    transition: transform 0.3s;
}

.image-row img:hover,
.section-image:hover {
    transform: scale(1.05);
}

/* ====== Footer ====== */
footer {
    width: 100%;
    background-color: #8b5a2b;
    padding: 40px 50px;
    display: flex;
    flex-direction: column;
    justify-content: center;
    align-items: center;
    box-shadow: 0 2px 5px rgba(0,0,0,0.1);
    color: white;
    font-size: 20px;
    margin-top: auto; /* keeps footer at bottom */
}

footer h2 {
    margin: 0 0 10px;
    font-size: 35px;
	color:white;
	font-weight:bold;
}

.social-links {
    display: flex;
    gap: 15px;
    margin-bottom: 10px;
	font-weight:bold;
}

.social-links a {
    color: white;
    font-size: 25px;
    text-decoration: none;
    transition: opacity 0.3s;
}

.social-links a:hover {
    opacity: 0.8;
}

.social-links .whatsapp {
  color: #25D366; 
  font-size: 28px; 
}
.social-links .instagram {
  color: #C13584; 
  font-size: 28px;
}



.email-line {
    display: flex;
    align-items: center;
    gap: 5px;
    font-weight: bold;
    font-size:25px;
	justify-content: center;
}

.email-line a {
    color: white;
    text-decoration: none;
}

.email-line a:hover {
    text-decoration: underline;
}
.email-line i {
  color: #0078D4; 
  font-size: 28px;
}

/* ====== Figure & Caption ====== */
.image-item {
    text-align: center;
}

figcaption {
    margin-top: 10px;
    font-size: 20px;
    font-weight: bold;
    color: #654321;
}
 /* ====== Centered Button ====== */
    .center-container {
      flex: 1;
      display: flex;
      justify-content: center;
      align-items: center;
      margin: 0;
      padding: 0;
    }

    .order-btn {
      display: inline-flex;
      align-items: center;
      justify-content: center;
      margin: 0;
      padding: 15px 30px;
      background-color: #D8C3A5;
      color: #654321;
      font-size: 25px;
      font-weight: bold;
      border: none;
      border-radius: 30px;
      cursor: pointer;
      text-decoration: none;
      box-shadow: 0 5px 15px rgba(0,0,0,0.2);
      transition: all 0.3s ease;
    }