<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
	<link href="https://fonts.googleapis.com/css2?family=Caveat&display=swap" rel="stylesheet">
  <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
    <title>Gallery</title>
    <style>
/* ====== Body ====== */
body {
    margin: 0;
    padding: 0;
    font-family: 'Dessert Script', cursive;
    background-color: #C2B7A2;
    display: flex;
    justify-content: center;
    align-items: center;
    flex-direction: column;
	
}
/* ====== Header ====== */
header {
    width: 100%;
    background-color: #E3DFCE;
    padding: 20px 50px;
    display: flex;
    justify-content: space-between;
    align-items: center;
    box-shadow: 0 2px 5px rgba(0,0,0,0.1);
	font-weight:bold;
	 
}

nav a {
    color: black;
    text-decoration: none;
    margin-left: 30px;
    font-size:50px;
}

nav a:hover {
    color: white;
}
footer {
    width: 100%;
    background-color:#E3DFCE;
    padding:0px 10px 10px;
    display: flex;
    flex-direction: column;
    justify-content: center;
    align-items: center;

    box-shadow: 0 2px 5px rgba(0,0,0,0.1);
    color:black;  
    font-size: 20px;
	position: fixed; 
	bottom: 0;        
    left: 0;
	line-height: 1.2;
}

footer h2 {
    margin: 0 0 10px;
    font-size: 35px;
	color:black;
	font-weight:bold;
	text-align: center; 
}

.social-links {
    display: flex;
    gap: 15px;
    margin-bottom: 10px;
	font-weight:bold;
}

.social-links a {
    color: black;
    font-size: 25px;
    text-decoration: none;
    transition: opacity 0.3s;
}

.social-links a:hover {
text-decoration: underline;
}

.social-links .whatsapp {
  color: #25D366; 
  font-size: 28px;
text-decoration: underline;  
}
.social-links .instagram {
  color: #C13584; 
  font-size: 28px;
  text-decoration: underline;
}



.email-line {
    display: flex;
    align-items: center;
    gap:10px;
    font-weight: bold;
    font-size:25px;
	justify-content: center;

}

.email-line a {
    color:black;
    text-decoration: none;
}

.email-line a:hover {
    text-decoration: underline;
}
.email-line i {
  color: #0078D4; 
  font-size: 28px;
}
/*==============================================================*/

.title {
            text-align: center;
            margin: 20px 0;
			font-size:120px;
			font-family:Caveat;
			font-weight:bold;
			margin-bottom:30px;
        }

       /* Category Buttons */
.tabs {
    text-align: center;
    margin-bottom: 30px;
    flex-wrap: wrap;
}

.tab-button {
    padding: 12px 25px;
    margin: 5px;
    border: none;
    background-color: #ddd;
    color: #333;
    font-size:20px;
    cursor: pointer;
    border-radius: 10px;
    transition: 0.3s;
	font-family: cursive;
	font-weight:bold;
}

.tab-button.active {
    background-color: #E3DFCE;
    color: black;
	font-size:25px;
	font-weight:bold;
	font-family: cursive;
}

/* Grid-style image display */
.gallery {
    display: none;
    justify-content: center;
    gap: 20px;
    flex-wrap: wrap;
}

.gallery.active {
    display: flex;
}

.gallery img {
    width: 260px;
    height: 260px;
    object-fit: cover;
    border-radius: 15px;
    box-shadow: 0 4px 10px rgba(0,0,0,0.2);
    transition: 0.3s;
}

.gallery img:hover {
    transform: scale(1.05);
}

    </style>
</head>
<body>
 <header>
 <nav>
<a href="h1.php">Home</a>
  </nav>
  </header>
    <h1  class="title">Gallery</h1>
 <div class="tabs">
    <button class="tab-button active" data-tab="tab1">Appetizers</button>
    <button class="tab-button" data-tab="tab2">Main Dishes</button>
    <button class="tab-button" data-tab="tab3">Desserts</button>
    <button class="tab-button" data-tab="tab4">Drinks</button>
	<button class="tab-button" data-tab="tab7">Salad</button>
	<button class="tab-button" data-tab="tab5">Our Previous Events</button>
	
</div>

<!-- --- Appetizers --- -->
<div class="gallery active" id="tab1">
    <img src="img/Appetizers/s5.jpg">
    <img src="img/Appetizers/s14.jpg">
    <img src="img/Appetizers/s28.jpg">
	<img src="img/Appetizers/s29.jpg">
    <img src="img/Appetizers/s30.jpg">
    <img src="img/Appetizers/s31.jpg">
	<img src="img/Appetizers/s32.jpg">
	<img src="img/Appetizers/s35.jpg">
	<img src="img/Appetizers/s39.jpg">
	<img src="img/Appetizers/s44.jpg">
	<img src="img/Appetizers/s45.jpg">
	<img src="img/Appetizers/s46.jpg">
	<img src="img/Appetizers/s58.jpg">
	<img src="img/Appetizers/s59.jpg">
	<img src="img/Appetizers/s60.jpg">
	<img src="img/Appetizers/s61.jpg">	
</div>

<!-- --- Main Dishes --- -->
<div class="gallery" id="tab2">
    <img src="img/Main Dishes/s1.jpg">
    <img src="img/Main Dishes/s2.jpg">
    <img src="img/Main Dishes/s3.jpg">
	<img src="img/Main Dishes/s4.jpg">
	<img src="img/Main Dishes/s7.jpg">
	<img src="img/Main Dishes/s8.jpg">
	<img src="img/Main Dishes/s11.jpg">
	<img src="img/Main Dishes/s12.jpg">
	<img src="img/Main Dishes/s13.jpg">
	<img src="img/Main Dishes/s15.jpg">
	<img src="img/Main Dishes/s26.jpg">
	<img src="img/Main Dishes/s27.jpg">
</div>

<!-- --- Desserts --- -->
<div class="gallery" id="tab3">
    <img src="img/Desserts/s16.jpg">
    <img src="img/Desserts/s17.jpg">
	<img src="img/Desserts/s18.jpg">
	<img src="img/Desserts/s19.jpg">
	<img src="img/Desserts/s20.jpg">
	<img src="img/Desserts/s21.jpg">
	<img src="img/Desserts/s24.jpg">
	<img src="img/Desserts/s25.jpg">
	
</div>

<!-- --- Drinks --- -->
<div class="gallery" id="tab4">
    <img src="img/Drinks/s49.jpg">
    <img src="img/Drinks/s50.jpg">
    <img src="img/Drinks/s51.jpg">
	<img src="img/Drinks/s52.jpg">
    <img src="img/Drinks/s53.jpg">
    <img src="img/Drinks/s54.jpg">
	<img src="img/Drinks/s55.jpg">
	<img src="img/Drinks/s62.jpg">
	<img src="img/Drinks/s63.jpg">
	<img src="img/Drinks/s64.jpg">
	<img src="img/Drinks/s65.jpg">
	<img src="img/Drinks/s66.jpg">
	<img src="img/Drinks/s67.jpg">
	<img src="img/Drinks/s68.jpg">
</div>

<!-- Our Previous Events -->
<div class="gallery" id="tab5">
    <img src="img/Our Previous Events/s22.jpg">
    <img src="img/Our Previous Events/s23.jpg">
    <img src="img/Our Previous Events/s33.jpg">
	<img src="img/Our Previous Events/s34.jpg">
    <img src="img/Our Previous Events/s48.jpg">
    <img src="img/Our Previous Events/s57.jpg">
	<img src="img/Our Previous Events/s69.jpg">
	<img src="img/Our Previous Events/s70.jpg">
	<img src="img/Our Previous Events/s71.jpg">
	<img src="img/Our Previous Events/s72.jpg">
	<img src="img/Our Previous Events/s73.jpg">
</div>
<!-- --- Salad --- -->
<div class="gallery" id="tab7">
    <img src="img/Salad/s6.jpg">
    <img src="img/Salad/s9.jpg">
    <img src="img/Salad/s36.jpg">
	<img src="img/Salad/s37.jpg">
	<img src="img/Salad/s38.jpg">
	<img src="img/Salad/s41.jpg">
	<img src="img/Salad/s42.jpg">
	<img src="img/Salad/s43.jpg">
	<img src="img/Salad/s47.jpg">
	<img src="img/Salad/s56.jpg">
</div>

  <!-- JavaScript for switching tabs -->
<script>
    const buttons = document.querySelectorAll(".tab-button");
    const galleries = document.querySelectorAll(".gallery");

    buttons.forEach(btn => {
        btn.addEventListener("click", () => {
            // Remove active class from all buttons and galleries
            buttons.forEach(b => b.classList.remove("active"));
            galleries.forEach(g => g.classList.remove("active"));

            // Add active class to the clicked button and its gallery
            btn.classList.add("active");
            document.getElementById(btn.dataset.tab).classList.add("active");
        });
    });
</script>
<footer>
  <div class="fooS">
    <div class="footer-content">
      <h2>CONTACT :</h2>

      <div class="social-links">
        <a href="https://wa.me/968XXXXXXXX" target="_blank">
          <i class="fab fa-whatsapp whatsapp"></i> +968 9333 5120
        </a>
        <a href="https://www.instagram.com/" target="_blank">
          <i class="fab fa-instagram instagram"></i> Aroma.om
        </a>
      </div>

      <div class="email-line">
        <i class="fas fa-envelope"></i>
        <a href="mailto:folk@gmail.com">AROMA@gmail.com</a>
      </div>

    </div>
  </div>
</footer>
</body>
</html>
