<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8">

<meta name="viewport" content="width=device-width, initial-scale=1.0">
<link href="https://fonts.googleapis.com/css2?family=Caveat&display=swap" rel="stylesheet">
<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
<title>FAQ & Feedback</title>
<style>
body {
    font-family: 'Dessert Script', cursive;
    background-color: #C2B7A2;
    display: flex;
    flex-direction: column;
    align-items: center;
    min-height:100vh;
    margin: 0;
    padding: 20px;
    gap:100px; /* space between boxes */
}
/*====================================================*/
header {
    width:100%;
    background-color: #E3DFCE;
    padding: 20px 50px;
    display: flex;
    justify-content: space-between;
    align-items: center;
    box-shadow: 0 2px 5px rgba(0,0,0,0.1);
    color: black;
	position: fixed;
	top: 0;            
    left: 0;          
    width: 100%;       
    z-index: 1000; 
    
}

nav a {
    color: black;
    text-decoration: none;
    margin-left: 30px;
    font-size:50px;
    font-style: italic;
    font-weight: bold;
    transition: color 0.3s ease;
}

nav a:hover {
    color: white;
}
footer {
    width: 100%;
    background-color:#E3DFCE;
    padding:0px 10px 10px;
    display: flex;
    flex-direction: column;
    justify-content: center;
    align-items: center;

    box-shadow: 0 2px 5px rgba(0,0,0,0.1);
    color:black;  
    font-size: 20px;
	position: fixed; 
	bottom: 0;        
    left: 0;
	line-height: 1.2;
}

footer h2 {
    margin: 0 0 10px;
    font-size: 35px;
	color:black;
	font-weight:bold;
	text-align: center; 
}

.social-links {
    display: flex;
    gap: 15px;
    margin-bottom: 10px;
	font-weight:bold;
}

.social-links a {
    color: black;
    font-size: 25px;
    text-decoration: none;
    transition: opacity 0.3s;
}

.social-links a:hover {
text-decoration: underline;
}

.social-links .whatsapp {
  color: #25D366; 
  font-size: 28px;
text-decoration: underline;  
}
.social-links .instagram {
  color: #C13584; 
  font-size: 28px;
  text-decoration: underline;
}



.email-line {
    display: flex;
    align-items: center;
    gap:10px;
    font-weight: bold;
    font-size:25px;
	justify-content: center;

}

.email-line a {
    color:black;
    text-decoration: none;
}

.email-line a:hover {
    text-decoration: underline;
}
.email-line i {
  color: #0078D4; 
  font-size: 28px;
}
/*====================================================*/
/* ===== Common Box Styling ===== */
.faq-box, .feedback-box {
    background-color: #E3DFCE;
    padding: 50px 60px;
    border-radius: 25px;
    box-shadow: 0 6px 20px rgba(0,0,0,0.2);
    width: 100%;
    max-width: 650px;
    text-align: center;
    display: flex;
    flex-direction: column;
    gap:5px;
    color: #000;   
    margin-bottom: 50px;
}

/* ===== Titles ===== */
.faq-box h2, .feedback-box h2 {
    font-size: 32px;
    font-weight: bold;
    margin-bottom:0px;
    color: #000;
}

.faq-box h1 {
    font-size:30px;
    color: #000;
	font-weight:bold;
}

.faq-box p {
    font-size:20px;
	font-weight:bold;
    line-height: 1;
    color: #000;
}

/* ===== Inputs & Textarea ===== */
.faq-box textarea, .feedback-box input, .feedback-box textarea {
    width: 100%;
    padding: 14px;
    border-radius: 10px;
    border: 1px solid #ccc;
    font-size:20px;
	font-weight:bold;
	color:black;
    transition: 0.3s;
}

.faq-box textarea:focus, .feedback-box input:focus, .feedback-box textarea:focus {
    border-color: #BAB7AE;
    box-shadow: 0 0 8px rgba(186,183,174,0.5);
    outline: none;
}

/* ===== Buttons ===== */
.faq-box button, .feedback-box button {
    background-color: #C2B7A2;
    color:black;
	font-weight:bold;
    border: none;
    padding: 12px 25px;
    border-radius: 15px;
    font-size:30px;
    cursor: pointer;
    transition: 0.3s;
	width: fit-content;
	margin:20px auto 0 auto;
}

.faq-box button:hover, .feedback-box button:hover {
    background-color: #fff;
    color: #A8987C;
    border: 1px solid #BAB7AE;
    transform: scale(1.05);
}

/* ===== Confirmation Messages ===== */
.feedback-box .confirmation,
.faq-box .confirmation {
    background-color: #fff;
    color:black;
    padding: 10px 15px;
    border-radius: 10px;
    border: 1px solid #ccc;
    display: none;           /* hidden by default */
    margin-top: 10px;
    font-size:20px;
	font-weight:bold;
}

/* ===== Responsive ===== */
@media (max-width: 480px) {
    .faq-box, .feedback-box {
        padding: 30px 20px;
    }

    .faq-box h2, .feedback-box h2 {
        font-size: 24px;
    }

    .faq-box h1 {
        font-size: 22px;
    }

    .faq-box p {
        font-size:14px;
    }

    .faq-box button, .feedback-box button {
        width: 100%;
    }
}
.faq-title{
	font-size:80px;
	font-family:Caveat;
	font-weight:bold;
	margin-top:-50px;
	margin-bottom:-30px;
}
</style>
</head>
<body>
 <header>
    <nav>
      <a href="h1.php">Home</a>
    </nav>
  </header>
  <br><br><br><br>
  <h2 class="faq-title">Help & Support</h2>
<div class="faq-box">
    <h1>- Frequently Asked Questions - </h1>
    <p>Due to the high number of repeated questions,you can submit your question here:</p>
    <textarea placeholder="Type your question here..."></textarea>
    <button onclick="showConfirmation(this)">Submit</button>
    <div class="confirmation">Your question has been submitted!</div>
</div>

<div class="feedback-box">
    <h2>Leave Your Feedback</h2>
    <input type="text" placeholder="Your Name">
    <textarea placeholder="Write your feedback..."></textarea>
    <button onclick="showConfirmation(this)">Send</button>
    <div class="confirmation">Thank you for your feedback!</div>
</div>

<script>
function showConfirmation(btn) {
    const box = btn.parentElement;
    const message = box.querySelector('.confirmation');
    message.style.display = 'block';
    setTimeout(() => {
        message.style.display = 'none';
    }, 3000); // hides after 3 seconds
}
</script>
<footer>
  <div class="fooS">
    <div class="footer-content">
      <h2>CONTACT :</h2>

      <div class="social-links">
        <a href="https://wa.me/968XXXXXXXX" target="_blank">
          <i class="fab fa-whatsapp whatsapp"></i> +968 9333 5120
        </a>
        <a href="https://www.instagram.com/" target="_blank">
          <i class="fab fa-instagram instagram"></i> Aroma.om
        </a>
      </div>

      <div class="email-line">
        <i class="fas fa-envelope"></i>
        <a href="mailto:folk@gmail.com">AROMA@gmail.com</a>
      </div>

    </div>
  </div>
</footer>
</body>
</html>
